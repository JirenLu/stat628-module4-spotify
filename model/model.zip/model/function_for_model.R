sentiment_results <- read.csv("sentiment_analysis_results.csv")
lda_results <- read.csv("lda_results.csv")
topic_distribution <- read.csv("topic_distribution.csv", row.names = NULL)
topic_distribution <- as.matrix(topic_distribution)
data <- read.csv("demo.csv")

library(vader) # 用于情感分析
library(tm)    # 文本处理
library(topicmodels) # LDA 模型

# 定义合并后的函数
process_and_analyze <- function(data, description_col = "Description") {
  # 确保数据中包含指定的列
  if (!description_col %in% colnames(data)) {
    stop("The specified Description column does not exist in the dataset.")
  }
  
  # Step 1: Sentiment Analysis
  sentiment_scores <- vader_df(data[[description_col]])
  
  # Add sentiment classification to the dataframe
  data$Sentiment_Label <- ifelse(
    sentiment_scores$compound >= 0.05, "Positive",
    ifelse(sentiment_scores$compound <= -0.05, "Negative", "Neutral")
  )
  
  # Convert sentiment classification to numeric scores
  data$Sentiment_Label_Num <- ifelse(
    data$Sentiment_Label == "Positive", 1,
    ifelse(data$Sentiment_Label == "Negative", -1, 0)
  )
  
  # Step 2: Text Preprocessing
  corpus <- Corpus(VectorSource(data[[description_col]]))
  corpus <- tm_map(corpus, content_transformer(tolower))
  corpus <- tm_map(corpus, removePunctuation)
  corpus <- tm_map(corpus, removeNumbers)
  corpus <- tm_map(corpus, removeWords, stopwords("en"))
  corpus <- tm_map(corpus, stripWhitespace)
  
  # Create Document-Term Matrix
  dtm <- DocumentTermMatrix(corpus)
  dtm <- removeSparseTerms(dtm, 0.99) # Remove sparse terms
  
  # Check if there are enough documents
  if (nrow(dtm) < 9) {
    stop("Not enough documents to build the LDA model. Please provide more valid text.")
  }
  
  # Step 3: LDA Model Calculation
  lda_model <- LDA(dtm, k = 9, control = list(seed = 123))
  topic_distribution <- posterior(lda_model)$topics
  
  # Calculate entropy
  calculate_entropy <- function(prob_vector) {
    -sum(prob_vector * log(prob_vector), na.rm = TRUE)
  }
  entropy_values <- apply(topic_distribution, 1, calculate_entropy)
  
  # Normalize Topic_Entropy to [-1, 1]
  min_entropy <- 0.027745513682697072
  max_entropy <- 3.16992500143887
  normalized_entropy <- (2 * (entropy_values - min_entropy) / (max_entropy - min_entropy)) - 1
  
  # Determine the dominant topic for each document
  dominant_topic <- apply(topic_distribution, 1, which.max)
  
  # Define English names for the topics
  topic_names <- c(
    "Finance and Marketing",
    "Privacy and History",
    "Health and Relationships",
    "Sleep and Fitness",
    "Music and Entertainment",
    "Personal Development",
    "Sports",
    "Social Media",
    "Education and Choices"
  )
  
  # Add topic analysis results to the dataframe
  #data$Topic_Entropy <- entropy_values
  data$Normalized_Entropy <- normalized_entropy
  data$Dominant_Topic <- dominant_topic
  data$Topic_Name <- topic_names[dominant_topic]
  
  return(data)
}

# Usage example
# Assuming sentiment_results is a dataframe with a Description column
processed_data <- process_and_analyze(data)

# View the results
head(processed_data[, c("Description", "Sentiment_Label", "Sentiment_Label_Num", "Normalized_Entropy", "Dominant_Topic", "Topic_Name")])

