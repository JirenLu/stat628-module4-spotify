sentiment_results <- read.csv("sentiment_analysis_results.csv")
data <- read.csv("demo.csv")
lda_results <- read.csv("lda_results.csv")
topic_distribution <- read.csv("topic_distribution.csv", row.names = NULL)
topic_distribution <- as.matrix(topic_distribution)


library(vader) # 用于情感分析
library(tm)    # 文本处理
library(topicmodels) # LDA 模型

# 定义合并后的函数
process_and_analyze <- function(data, description_col = "Description") {
  # 确保数据中包含指定的列
  if (!description_col %in% colnames(data)) {
    stop("指定的 Description 列名在数据集中不存在。")
  }
  
  # Step 1: 情感分析
  sentiment_scores <- vader_df(data[[description_col]])
  
  # 添加情感分类到数据框
  data$Sentiment_Label <- ifelse(
    sentiment_scores$compound >= 0.05, "Positive",
    ifelse(sentiment_scores$compound <= -0.05, "Negative", "Neutral")
  )
  
  # 将情感分类转换为数值
  data$Sentiment_Score <- ifelse(
    data$Sentiment_Label == "Positive", 1,
    ifelse(data$Sentiment_Label == "Negative", -1, 0)
  )
  
  # Step 2: 文本预处理
  corpus <- Corpus(VectorSource(data[[description_col]]))
  corpus <- tm_map(corpus, content_transformer(tolower))
  corpus <- tm_map(corpus, removePunctuation)
  corpus <- tm_map(corpus, removeNumbers)
  corpus <- tm_map(corpus, removeWords, stopwords("en"))
  corpus <- tm_map(corpus, stripWhitespace)
  
  # 创建 Document-Term Matrix
  dtm <- DocumentTermMatrix(corpus)
  dtm <- removeSparseTerms(dtm, 0.99) # 移除稀疏词项
  
  # 检查是否有足够的文档
  if (nrow(dtm) < 9) {
    stop("文档数不足以构建 LDA 模型，请提供更多有效文本。")
  }
  
  # Step 3: LDA 模型计算
  lda_model <- LDA(dtm, k = 9, control = list(seed = 123))
  topic_distribution <- posterior(lda_model)$topics
  
  # 计算熵
  calculate_entropy <- function(prob_vector) {
    -sum(prob_vector * log(prob_vector), na.rm = TRUE)
  }
  entropy_values <- apply(topic_distribution, 1, calculate_entropy)
  
  # 确定每个文档的主导主题
  dominant_topic <- apply(topic_distribution, 1, which.max)
  
  # 定义主题的英文名
  topic_names <- c(
    "Finance and Marketing",
    "Privacy and History",
    "Health and Relationships",
    "Sleep and Fitness",
    "Music and Entertainment",
    "Personal Development",
    "Sports",
    "Social Media",
    "Education and Choices"
  )
  
  # 添加主题分析结果到数据框
  data$Topic_Entropy <- entropy_values
  data$Dominant_Topic <- dominant_topic
  data$Topic_Name <- topic_names[dominant_topic]
  
  return(data)
}

# 使用函数
# 假设 sentiment_results 是包含 Description 列的数据框
processed_data <- process_and_analyze(data)

# 查看结果
head(processed_data[, c("Description", "Sentiment_Label", "Sentiment_Score", "Topic_Entropy", "Dominant_Topic", "Topic_Name")])
