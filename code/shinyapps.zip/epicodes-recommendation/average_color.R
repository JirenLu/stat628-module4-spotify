library(httr)  # 用于获取网页内容
library(jpeg)  # 用于读取 JPEG 图片
library(png)   # 用于读取 PNG 图片

calculate_rgb_mean_from_url <- function(image_url) {
  default_rgb <- c(67, 118, 162)  # 默认 RGB 值
  
  tryCatch({
    # 从 URL 获取图片内容
    # response <- GET(image_url)
    
    # 创建临时文件
    temp_file <- tempfile(fileext = ".jpg")
    # 下载图片到临时文件
    response <- GET(image_url, write_disk(temp_file, overwrite = TRUE))
    
    # 检查响应状态
    if (http_status(response)$category != "Success") {
      stop("Failed to fetch the image from URL")
    }
    
    # 读取图片为原始数据
    img_data <- readJPEG(temp_file)
    #img_data <- readJPEG(content(response))
    
    # 计算均值
    # 如果图片是彩色 (3D 数组)，计算每个通道的均值
    if (length(dim(img_data)) == 3) {
      avg_r <- mean(img_data[, , 1]) * 255  # R 通道
      avg_g <- mean(img_data[, , 2]) * 255  # G 通道
      avg_b <- mean(img_data[, , 3]) * 255  # B 通道
    } else {
      # 如果是灰度图片，用灰度值填充 RGB
      avg_r <- avg_g <- avg_b <- mean(img_data) * 255
    }
    # avg_r <- mean(img_data[seq(1, length(img_data), by = 3)])  # R通道
    # avg_g <- mean(img_data[seq(2, length(img_data), by = 3)])  # G通道
    # avg_b <- mean(img_data[seq(3, length(img_data), by = 3)])  # B通道
    
    # 返回 RGB 平均值
    c(avg_r = round(avg_r), avg_g = round(avg_g), avg_b = round(avg_b))
  }, error = function(e) {
    # 返回默认值并输出错误信息
    message("Error: ", e$message)
    setNames(default_rgb, c("avg_r", "avg_g", "avg_b"))
  })
}

combine_podcast_info_text <- function(total_episodes) {
  if (total_episodes <= 0) {
    return("No Episodes")
  } else {
    paste(
      total_episodes,
      ifelse(total_episodes == 1, "Episode", "Episodes")
    )
  }
}


convert_date <- function(date_str) {
  # 将字符串转换为日期对象
  date_obj <- as.Date(date_str, format = "%Y-%m-%d")
  # 格式化日期为目标格式
  formatted_date <- format(date_obj, "%b%e,%Y")
  # 去除多余的空格（针对 %e 的情况）
  gsub(" ", "", formatted_date)
}

convert_milliseconds <- function(milliseconds) {
  # 转换为秒
  total_seconds <- milliseconds / 1000
  # 计算小时、分钟和秒
  hours <- floor(total_seconds / 3600)
  minutes <- floor((total_seconds %% 3600) / 60)
  seconds <- round(total_seconds %% 60)
  # 根据小时是否为 0 格式化输出
  if (hours == 0) {
    sprintf("%dmin%dsec", minutes, seconds)
  } else {
    sprintf("%dhr%dmin", hours, minutes)
  }
}

# 合并日期和时间信息的函数
combine_episode_info_text <- function(date_str, milliseconds) {
  Sys.setlocale("LC_TIME", "C")
  # 调用日期转换函数
  formatted_date <- convert_date(date_str)
  # 调用毫秒转换函数
  formatted_duration <- convert_milliseconds(milliseconds)
  # 合并结果用点隔开
  paste(formatted_date, formatted_duration, sep = " · ")
}

# print(combine_episode_info_text("2023-09-09", 299049))
