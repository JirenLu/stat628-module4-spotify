library(httr)
library(jsonlite)

# 定义客户端 ID 和密钥（仅存储在此文件中）
client_id <- 
client_secret <- 

# 定义获取 Token 的函数
get_new_token <- function() {
  # 请求新 Token
  response <- POST(
    url = "https://accounts.spotify.com/api/token",
    authenticate(client_id, client_secret),
    body = list(grant_type = "client_credentials"),
    encode = "form"
  )
  
  if (response$status_code == 200) {
    # content <- fromJSON(content(response, "text", encoding = "UTF-8"))
    # content <- fromJSON(content(response, as = "text", encoding = "UTF-8"))
    # 假设 response 是 httr::POST 或 httr::GET 返回的对象
    raw_content <- rawToChar(response$content)
    # 设置编码为 UTF-8
    Encoding(raw_content) <- "UTF-8"
    # 使用 jsonlite::fromJSON 解析 JSON 内容
    content <- jsonlite::fromJSON(raw_content)
    return(content$access_token)
  } else {
    stop("Failed to fetch token. Check your client ID and secret.")
  }
}

# 对外导出函数
get_spotify_token <- function() {
  get_new_token()
}
