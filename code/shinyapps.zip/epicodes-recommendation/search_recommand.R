library(RANN)

data <- read.csv("data/episodes_list.csv")

# Function to find nearest neighbors
find_nearest_neighbors <- function(entropy_coords, sentiment_label, n_neighbors) {
  # print(entropy_coords, sentiment_label, n_neighbors)
  # 提取需要的列
  coords <- as.matrix(data[, c("Normalized_Entropy", "Sentiment_Label_Num")])

  # 创建目标点
  target_point <- matrix(c(entropy_coords, sentiment_label), nrow = 1)
  
  # 使用 RANN 包寻找最近邻
  nn_result <- nn2(data = coords, query = target_point, k = n_neighbors)
  
  # 提取最近邻索引和距离
  indices <- nn_result$nn.idx[1, ]
  distances <- nn_result$nn.dists[1, ]
  
  # 创建结果数据框
  result <- data[indices, ]
  result$Distance <- distances
  
  # 按距离排序（保险措施，通常 nn2 已经按距离返回）
  # result <- result[order(result$Distance), ]
  # result <- result[sample(nrow(result)), ]
  
  return(result)
}


# Example usage
# entropy_coords <- 1.95467
# sentiment_label <- 0.178
# n_neighbors <- 5
# result <- find_nearest_neighbors(entropy_coords, sentiment_label, n_neighbors)
# print(result)
