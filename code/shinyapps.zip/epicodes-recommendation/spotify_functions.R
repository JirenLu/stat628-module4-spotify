library(httr)
library(jsonlite)


# 定义数据处理函数
process_shows_data <- function(df) {
  # 提取 image_640 列
  df$image_640 <- sapply(df$images, function(image_list) {
    if (!is.null(image_list)) {
      url_640 <- image_list$url[image_list$height == 640]
      if (length(url_640) > 0) return(url_640[1]) else return(NA)
    } else {
      return(NA)
    }
  })
  # 提取 image_300 列
  df$image_300 <- sapply(df$images, function(image_list) {
    if (!is.null(image_list)) {
      url_300 <- image_list$url[image_list$height == 300]
      if (length(url_300) > 0) return(url_300[1]) else return(NA)
    } else {
      return(NA)
    }
  })
  # 提取 image_64 列
  df$image_64 <- sapply(df$images, function(image_list) {
    if (!is.null(image_list)) {
      url_64 <- image_list$url[image_list$height == 64]
      if (length(url_64) > 0) return(url_64[1]) else return(NA)
    } else {
      return(NA)
    }
  })
  return(df)
}



# Spotify 搜索函数
spotify_search <- function(query, token) {
  # 发起 GET 请求
  response <- GET(
    paste0("https://api.spotify.com/v1/search?q=", URLencode(query), "&type=show%2Cepisode&limit=3"),
    add_headers(Authorization = paste("Bearer", token))
  )
  
  # 检查响应状态
  if (response$status_code == 200) {
    # 解析响应内容
    # results_raw <- fromJSON(content(response, "text", encoding = "UTF-8"), simplifyVector = TRUE, flatten = TRUE)
    # 提取原始内容
    raw_content <- rawToChar(response$content)
    # 设置编码为 UTF-8
    Encoding(raw_content) <- "UTF-8"
    # 使用 jsonlite::fromJSON 并保留 simplifyVector 和 flatten 参数
    results_raw <- jsonlite::fromJSON(raw_content, simplifyVector = TRUE, flatten = TRUE)
    # 处理podcasts
    raw_shows_df <- as.data.frame(results_raw$shows$items)
    shows_df <- process_shows_data(raw_shows_df)
    columns_to_remove_shows <- c("available_markets", "copyrights", "explicit", "html_description", 
                                 "images", "is_externally_hosted", "uri")
    shows_df <- shows_df[, !(names(shows_df) %in% columns_to_remove_shows)]
    # 处理episodes
    raw_episodes_df <- as.data.frame(results_raw$episodes$items)
    episodes_df <- process_shows_data(raw_episodes_df)
    columns_to_remove_episodes <- c("html_description", "explicit", "images", "is_externally_hosted", 
                           "is_playable", "language", "release_date_precision", "resume_point", "uri")
    episodes_df <- episodes_df[, !(names(episodes_df) %in% columns_to_remove_episodes)]
    return(list(shows_df = shows_df, episodes_df = episodes_df))
  } else {
    stop("Failed to fetch data from Spotify API. Status: ", response$status_code)
  }
}


#token <- "BQCBCsHBrckZwPmXNBwiu-kjAGx1zhotplvWqfKrhB4WiIH5j_p8NPqKVfxYnr1-ncRXEV0kIVw2E3CZN0sVZbrhqSOrmV9zPoPB8IxnmcVHC3cSS1U"
#parsed_episodes <- spotify_search("jkah", token)
#print(parsed_episodes)
