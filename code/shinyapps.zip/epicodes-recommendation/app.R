# -----------------------------------------------------------------------------
# Shiny App: Recommand Spotify's Episodes
# Copyright (c) 2024 Jiren Lu
# 
# This application is licensed under the MIT License. You may obtain a copy of
# the License at https://opensource.org/licenses/MIT.
# -----------------------------------------------------------------------------

library(shiny)
library(shinyjs)
library(plotly)
source("token_manager.R")
source("spotify_functions.R")
source("average_color.R")
source("analyze_description.R")
source("search_recommand.R")

token <- get_spotify_token()

global_variable <- reactiveValues(id = NULL, type = NULL)
# search_change <- reactiveVal(FALSE)
global_episode <- reactiveValues(
  Podcast_ID = "5I215mpoRFa8ZbGcNtdMCv",
  Audio_Preview_URL = "https://podz-content.spotifycdn.com/audio/clips/7FHzB3EqnMgKkTUNuBo2Gd/clip_616760_676760.mp3",
  Description = "The Return of the King - Book 3, Part 2; by Tolkien. Read by Phil Dragash. Full Unabridged Audiobook Copyright Disclaimer under section 107 of the Copyright Act of 1976, allowance is made for \"fair use\" for purposes such as criticism, comment, news reporting, teaching, scholarship, education and research. Fair use is a use permitted by copyright statute that might otherwise be infringing.",
  Duration_MS = 150,
  External_URL = "https://open.spotify.com/episode/50cMpkihODgdsKVKJvcZ1b",
  Episode_ID = "50cMpkihODgdsKVKJvcZ1b",
  Image_640 = "https://i.scdn.co/image/ab6765630000ba8a92d65769afcd2eeea558a2fb",
  Image_300 = "https://i.scdn.co/image/ab67656300005f1f92d65769afcd2eeea558a2fb",
  Image_64 = "https://i.scdn.co/image/ab6765630000f68d92d65769afcd2eeea558a2fb",
  Languages = list("en"),
  Name = "The Return of the King - Book 3, Part 2",
  # Release_Date = "2023/8/30",
  Info_shown = "Aug8,2023 · 4hr10min",
  Type = "Episode",
  avg_color = "rgba(166, 18, 11, 0.6)",
  avg_color_1 = "rgba(166, 18, 11, 0.4)",
  avg_color_2 = "rgba(166, 18, 11, 0)"
)
global_search_result <- reactiveValues(df = NULL, ec = NULL, sln = NULL, sl = NULL)
global_playing <- reactiveValues(
  Audio_Preview_URL = "https://podz-content.spotifycdn.com/audio/clips/6RL6uyT11DWxl9uI2qXqRT/clip_255665_315665.mp3",
  External_URL = "https://open.spotify.com/episode/288x6ngo337UCilYCqLgiQ",
  Image_64 = "https://i.scdn.co/image/ab6765630000f68d89f65d01e1c6e39d4d4e64e8",
  Duration_S = 5237,
  Name = "222. Are Parents the Demise of Many Potential Pro Athletes?"
)
play <- reactiveVal(FALSE) # 初始状态为播放
global_num_recommand <- reactiveVal(6)


# 触发器id生成器
id_generator <- local({
  count <- 0  # 初始化计数器
  function() {
    count <<- count + 1  # 使用全局赋值更新计数器
    as.character(count)
  }
})


# 内部函数处理单个数据框
process_df <- function(df, type_label) {
  # 如果 df 是空表，直接返回空表
  if (nrow(df) == 0) {
    return(data.frame(id = character(), name = character(), image_64 = character(), type = character(), stringsAsFactors = FALSE))
  }
  # 过滤掉 id、name 或 description 为空的行
  df <- df[!(is.na(df$id) | df$id == "" | 
               is.na(df$name) | df$name == "" | 
               is.na(df$description) | df$description == ""), ]
  # 添加 type 列
  df$type <- type_label
  # 提取并保留指定列
  df <- df[, c("id", "name", "image_64", "type"), drop = FALSE]
  return(df)
}

show_search <- function(shows_df, episodes_df, query, session){
  # 处理 shows_df 和 episodes_df
  processed_shows <- process_df(shows_df, "Podcast")
  processed_episodes <- process_df(episodes_df, "Episode")
  # 合并两张表
  combined_df <- rbind(processed_episodes, processed_shows)
  combined_df$name <- trimws(combined_df$name)
  # 检查是否有与 query 完全相同的 name
  exact_match <- which(tolower(combined_df$name) == tolower(query))
  if (length(exact_match) > 0) {
    # 将完全匹配的行移到第一行
    combined_df <- combined_df[c(exact_match, setdiff(seq_len(nrow(combined_df)), exact_match)), ]
  }
  # print(combined_df)
  ui_cards <- lapply(seq_len(nrow(combined_df)), function(i){
    row <- combined_df[i, ]
    #id <- paste0("card_", i) # 动态生成按钮 ID
    id <- id_generator()
    button_ui <- actionButton(
      inputId = id,
      style = "background: none; border: none;",
      label = div(
        class = "search-card",
        div(
          style = "width: 70px; height: 70px; display: flex; justify-content: center; margin-right: 10px; margin-left: 5px",
          img(src = row$image_64, 
              style = "width: 64px; height: 64px; border-radius: 10%;",
              onerror = "this.src='spotify.jpg';")
        ),
        div(
          style = "display: flex; flex-direction: column; align-items: flex-start; ",
          div(
            style = "width: 305px; font-weight: bold; color: #fff; display: -webkit-box; 
            -webkit-line-clamp: 2; -webkit-box-orient: vertical; text-overflow: ellipsis;
            overflow: hidden;  text-align: left; word-wrap: break-word; white-space: normal;",
            trimws(row$name) # 删除左边的空格
          ),
          div(
            style = "font-size: 10px; color: gray; margin-top: 3px;",
            row$type
          )
        )
      )
    )
    # 创建监听器
    local({
      current_name <- row$name
      observer <- observeEvent(session$input[[id]], {
        # print(paste0("点击", query, id))
        global_variable$id <- row$id
        global_variable$type <- row$type
      }, once = TRUE)
    })
    return(button_ui) # 返回按钮组件
  })
  ui_cards <- div(
    class = "dropdown-item", # 整体外层的类
    style = "display: flex; flex-wrap: wrap; justify-content: center; padding: 10px;", # 可选样式
    ui_cards
  )
  return(ui_cards)
}


ui <- fluidPage(
  useShinyjs(),
  tags$head(
    tags$style(HTML("
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      html, body {
        width: 100%;
        height: 100%;
        overflow: hidden; /* 防止滚动条 */
        background-color: #000000;
        font-family: 'Arial Rounded MT Bold', sans-serif;
        user-select: none;
      }
      
      .container {
        display: flex;
        flex-direction: column;
        align-items: center; /* 垂直居中 */
        justify-content: center; /* 水平居中 */
      }
      
      .main-container {
        display: flex;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        #background-color: #1db954;
      }
      
      .header {
        height: 65px;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        font-weight: bold;
        width: 100%;
        margin: 0;
      }
      
      .header-left {
        width: 20%;
        display: flex;
        align-items: center;
        justify-content: left;
      }
      
      .header-right {
        width: 20%;
        display: flex;
        align-items: center;
        justify-content: right;
      }
      
      .header-middle {
        width: 60%;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      
      .header-left-icon img{
        height: 32px; /* 图片自适应宽度 */
        width: 32px; /* 保持图片比例 */
        cursor: pointer; /* 鼠标悬停时显示为指针 */
        margin-left: 40px;
      }
      
      .search_container{
        display: flex;
        align-items: center;
        background-color: rgb(31, 31, 31);
        border-radius: 25px;
        height: 43px;
        width: 480px;
        padding: 10px 15px;
        position: relative;
      }
      
      .search-input {
        flex: 1;
        background: transparent;
        border: none;
        outline: none;
        color: #fff;
        font-size: 18px;
        margin-left: 4px;
        margin-top: 3px;
        font-weight: 400;
        font-family: 'Calibri';
        padding-right: 30px; /* 给按钮留出空间 */
      }
      .search-input::placeholder {
        color: #666;
      }
      
      .dropdown {
        position: absolute;
        top: 100%; /* 距离输入框底部 */
        left: 50%;
        transform: translateX(-50%);
        backdrop-filter: blur(3px);
        width: 88%;
        border: 1px solid #ccc;
        background: rgba(0, 0, 0, 0.6);
        z-index: 1000; /* 保证弹窗在最上层 */
        border-radius: 7px;
        padding: 5px 0;
        margin-top: 4px;
        display: none;
      }
      .dropdown.show {
        display: block; /* 显示下拉框 */
      }
      .dropdown-item {
        display: flex;
        justify-content: center;
        padding: 10px;
        font-size: 14px;
        color: #333;
        # pointer-events: none;      /* 禁止鼠标点击事件 */
        cursor: default;
      }
      .dropdown-item.no-results {
        text-align: center;       /* 文本居中 */
        color: white;             /* 文字颜色为白色 */
        padding: 10px;            /* 增加一些内边距，优化视觉效果 */
        font-size: 16px;          /* 字体大小（可根据需要调整） */
      }
      
      .search-card {
        display: flex;                 /* 启用 Flexbox，使内容水平排列 */
        justify-content: flex-start;
        background-color: transparent; /* 背景透明 */
        width: 100%;                   /* 宽度占满父容器 */
        height: 80px;                  /* 固定高度 80px */
        width: 400px;
        border: none;                  /* 移除默认边框 */
        cursor: pointer;               /* 鼠标悬停时显示手型 */
        padding-top: 8px;
        text-decoration: none;
      }
      .search-card:hover {
        background-color: rgba(255, 255, 255, 0.1);
        transform: scale(1.04);
      }
      
      .footer {
        height: 80px;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        font-weight: bold;
        #width: 100vw;
        margin: 0;
      }
      
      .player-container {
        display: grid;
        grid-template-columns: 1fr 600px 1fr;
        height: 100%; /* 占满父容器高度 */
        width: 100%; /* 占满父容器宽度 */
        display: inline-flex;
      }
      .player-container-center {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
        width: 100%;
        height: 100%; /* 设置容器高度 */
      }
      .player-controls {
        height: 60px;
        width: 260px;
        display: grid;
        grid-template-columns: 1fr 1fr 1.2fr 1fr 1fr;
        justify-content: center;
        align-items: center;
      }
      .player-controls-button {
        position: relative; /* 确保子元素相对于这个容器定位 */
        overflow: hidden;
        display: inline-flex; /* 按钮大小仅包裹符号 */
        align-items: center; /* 垂直居中 */
        justify-content: center; /* 水平居中 */
        broder: none;
        height: 30px; 
        color: rgb(179, 179, 179);
        font-size: 50px;
        cursor: pointer;
        border: none;
        background: #000000;
        padding: 0; /* 移除内边距 */
        outline: none; /* 无点击框 */
      }
      .player-controls-button:hover {
        background: #000000;
        color: rgb(237, 237, 237)
      }
      .player-controls-button:focus {
        outline: none;
        background: #000000;
        color: rgb(120, 120, 120); /* 点击时改变颜色 */
      }
      .player-controls-button-play {
        width: 34px; /* 容器宽度 */
        height: 34px; /* 容器高度 */
        background-color: white; /* 白色背景 */
        color: black; /* 黑色文字 */
        border: none; /* 无边框 */
        border-radius: 50%; /* 圆形 */
        display: flex; /* 使用 flex 布局 */
        align-items: center; /* 垂直居中 */
        justify-content: center; /* 水平居中 */
        font-size: 20px; /* 字体大小 */
        cursor: pointer; /* 鼠标变为手形 */
      }
      .offset-type-1 { /* 播放键偏移量样式 */
        transform: translate(1.5px, 1px); /* 图标向右下偏移 */
      }
      .offset-type-2 { /* 暂停键偏移量样式 */
        transform: translate(-0.1px, 1.1px); /* 图标向左上偏移 */
      }
      .player-controls-button-play:hover {
        background-color: rgb(201, 201, 201);
      }
      
      .song-box {
        width: 160px;
        text-align: left;
      }
      .song-title {
        font-size: 14px;
        color: rgba(255, 255, 255, 0.9);
        line-height: 1.4;
        display: -webkit-box;
        -webkit-line-clamp: 2; /* 显示最多两行 */
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
        margin-top: 7px;
      }
      .song-title a {
        text-decoration: none; /* 默认无下划线 */
        color: inherit;
      }
      .song-title a:hover {
        text-decoration: underline; /* 鼠标悬停时出现下划线 */
        color: rgb(255, 255, 255);
      }
      
      .time-bar-container {
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 600px; /* 总宽度 */
        height: 20px; /* 容器高度 */
      }
      .time-bar-left,
      .time-bar-right {
        width: 50px; /* 左右部分各50px */
        height: 100%; /* 高度与容器一致 */
        display: flex;
        align-items: flex-start;
        font-size: 12px;
        color: rgb(178, 178, 178);
        margin-top: -12px;
        
      }
      .time-bar-center {
        width: 500px; /* 中间部分500px */
        height: 100%; /* 高度与容器一致 */
        # background-color: #90ee90; /* 中间部分颜色（浅绿） */
        display: flex;
        align-items: flex-start;
        justify-content: center;
      }
      
      .progress-container {
        display: flex;
        align-items: center;
        width: 480px; /* 总进度条长度 */
        height: 5px; /* 容器高度 */
        background-color: rgb(77, 77, 77);
        border-radius: 10px; /* 圆角 */
        position: relative;
        cursor: pointer;
      }
      .progress-bar {
        height: 100%;
        width: 0%; /* 初始进度为 0% */
        background-color: rgb(255, 255, 255); /* 播放进度颜色 */
        border-radius: 10px;
        transition: width 0.1s; /* 平滑过渡 */
      }
      .progress-container:hover .progress-bar {
        background-color: #1ed760; /* 悬停时的 Spotify 绿色 */
      }
      .boundary-marker {
        position: absolute;
        top: 50%; /* 垂直居中 */
        transform: translateY(-50%); /* 修正垂直偏移 */
        width: 5px; /* 红点宽度 */
        height: 5px; /* 红点高度 */
        background: rgba(255, 0, 0, 0.5); /* 红点颜色 */
        border-radius: 50%; /* 圆形红点 */
      }
      
      .main {
        flex: 1; /* 自动占据中间剩余空间 */
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        margin-left: 12px;
        margin-right: 12px;
        height: calc(100vh - 65px - 80px); /* 减去 header 和 footer 的高度 */
        overflow: hidden;
      }
      
      .main-left {
        background-color: rgb(18, 18, 18);
        width: 30vw;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border-radius: 6px;
        overflow: hidden;
      }
      .main-left-top {
        flex: 6; /* 占 60% 高度 */
        display: flex;
        justify-content: center;
        # background-color: #f4f4f4;
        width: 100%;
        margin: 0; 
        padding: 0;
        box-sizing: border-box;
        overflow-y: scroll;
        scrollbar-width: none; /* 适用于 Firefox */
        -ms-overflow-style: none; /* 适用于 IE 和 Edge */
      }
      .main-left-top::-webkit-scrollbar {
        display: none; /* 适用于 Chrome、Safari */
      }
      .main-left-bottom {
        flex: 4; /* 占 40% 高度 */
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        overflow: hidden;
      }
      
      .main-left-top-play-button {
        position: absolute;  /* 绝对定位 */
        position: absolute;  /* 绝对定位 */
        width: 34px;         /* 按钮宽度 */
        height: 34px;        /* 按钮高度 */
        bottom: 8px;         /* 距离容器底部5px */
        right: 10px;         /* 距离容器右侧10px */
        background-color: rgb(30, 215, 96);
        color: rgb(0, 0, 0);
        border: none;        /* 无边框 */
        border-radius: 50%;  /* 圆角 */
        cursor: pointer;     /* 鼠标样式 */
        display: flex;       /* 用于居中对齐内容 */
        align-items: center; /* 垂直居中 */
        justify-content: center; /* 水平居中 */
        font-size: 20px;
        transition: all 0.1s ease; /* 动态过渡效果 */
      }
      .main-left-top-play-button:hover {
        background-color: rgb(59, 228, 119); /* 悬停时变亮 */
        transform: scale(1.1); /* 悬停时放大 1.2 倍 */
      }
      
      .main-right {
        width: 70vw;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 6px;
        overflow: hidden;
        box-sizing: border-box;
      }
      
      .scrollable-content {
        width: 100%;
        height: 100%;
        overflow-y: auto;
        box-sizing: border-box;
      }
       .scrollable-content::-webkit-scrollbar {
        display: none; /* 隐藏滚动条（Chrome/Safari/Edge） */
      }

      .podcast_recommendation_title {
        width: 100%; /* 宽度占满父容器 */
        height: 150px; /* 固定高度，示例为200px */
        background: linear-gradient(to bottom right, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.1));
        overflow-y: auto; /* 如果内容溢出，启用滚动 */
        box-sizing: border-box; /* 包括内边距在宽高计算内 */
      }
      
      .podcast_recommendation_title_font {
        color: #FFFFFF; /* 字体颜色 */
        font-family: Arial Black, sans-serif; /* 指定字体 */
        font-weight: 900;
        text-align: left; /* 文本左对齐 */
        font-size: 56px;
        margin-top: 46px;
        margin-left: 20px;
      }
      
      .podcast_recommendations {
        background: linear-gradient(to bottom, 
          rgba(255, 255, 255, 0.1) 0px, /* 起始颜色 */
          rgba(18, 18, 18, 1) 200px, /* 在300px处完成渐变 */
          rgb(18, 18, 18) 100% /* 超过300px后保持固定颜色 */
        );
      }
      
      .recommand-card-container {
        display: flex;          /* 使用 flexbox 布局 */
        flex-wrap: wrap;        /* 超出范围换行 */
        padding: 40px 18px 18px 18px; /* 上边距 30px，右边距 14px，下边距 14px，左边距 14px */
        gap: 18px;              /* 子元素之间的间距 */
        justify-content: center;
      }
      .recommand-card {
        flex: 0 0 calc(33.33% - 18px); /* 每行 3 个元素，减去间距 */
        aspect-ratio: 3/4;          /* 宽高比 */
        border-radius: 8px;           /* 卡片圆角 */
        padding: 10px;                /* 卡片内边距 */
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 卡片阴影 */
        background-color: #fff;       /* 卡片背景颜色 */
        text-align: center;           /* 内容居中 */
        display: flex;                /* 使用 Flexbox 布局 */
        flex-direction: column;
        max-width: calc(3 * (33.33% + 18px));
        overflow: hidden;
      }
      .recommand-card:hover {
        cursor: pointer;
      }
      .recommand-card .top {
        #flex: 1;                      /* 占比 1 */
        height: 20%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;          /* 内容居中对齐 */
      }
      .recommand-card .top .top-upper {
        max-height: 50px;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        overflow: hidden;
        text-align: left;
      }
      .recommand-card .top .top-upper h5 {
        font-size: 20px;               /* 设置字号 */
        font-weight: 800;              /* 加粗 */
        # line-height: 1.2;              /* 行高 */
        color: rgba(255, 255, 255, 0.95);
        margin: 0 9px;
        text-overflow: ellipsis;       /* 超出部分显示省略号 */
        overflow: hidden;              /* 隐藏溢出文本 */
        display: -webkit-box;          /* 必须用于限制行数 */
        -webkit-line-clamp: 2;         /* 限制为两行 */
        -webkit-box-orient: vertical;  /* 垂直排列 */
      }
      .recommand-card .top .top-lower {
        max-height: 25px;
        display: flex;
        # justify-content: center;
        color: rgba(255, 255, 255, 0.7); 
        font-size: 14px; 
        margin-top: 10px;
      }
      .recommand-card .middle {
        flex: 3;                      /* 占比 3 */
        display: flex;
        justify-content: center;
        align-items: center;          /* 内容居中对齐 */
        transition: flex 0.5s ease;
        will-change: transform;
        overflow: hidden;
      }
      .recommand-card:hover .middle {
        flex: 2;                      /* 缩小到占比 2 */
      }
      .recommand-card .middle img {
        height: 90%;              /* 高度占容器的 90% */
        width: auto;              /* 宽度根据比例自适应 */
        # aspect-ratio: 1;
        #max-height: 280px;        /* 最大高度为 300px */
        #max-width: 280px;
        object-fit: contain;       /* 保持图片比例，不裁剪 */
        display: block;           /* 防止图片默认的 inline 属性导致布局异常 */
        margin: 0 auto;           /* 图片居中 */
        border-radius: 5px;
        transition: flex 0.5s ease;
        will-change: transform;
      }
      .recommand-card .bottom {
        flex: 1;                      /* 占比 1 */
        transition: flex 0.5s ease;
        #height: 100%;
        #padding: 10px;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
      }
      .recommand-card:hover .bottom {
        flex: 2;                      /* 增大到占比 2 */
      }
      .recommand-card .bottom .sub-container {
        height: 100%;                   /* 初始高度为 100% */
        width: 100%;                    /* 子容器宽度占满 */
        # background-color: rgba(0, 0, 0, 0.1); /* 子容器背景色（可调整） */
        transition: height 0.5s ease;   /* 平滑高度过渡 */
        display: flex;
        justify-content: center;
        align-items: flex-start;
        border-radius: 7px;
        overflow: hidden;
        position: absolute;
      }
      .recommand-card .bottom .sub-container .sub-sub-container {
        height: 200px;
        width: 100%;
        white-space: normal;            /* 正常换行 */
        text-overflow: ellipsis;        /* 超出部分显示省略号 */
        overflow: hidden;               /* 隐藏超出内容 */
        transition: -webkit-line-clamp 0.6s ease; /* 平滑过渡行数 */
        font-size: 12px;
        display: flex;
        flex-direction: column;
      }
      .recommand-card .bottom .sub-container .sub-sub-container .top-child {
        height: 170px;                  /* 上子容器固定高度 */
        width: 100%;                    /* 宽度占满父容器 */
        display: flex;
        align-items: flex-start;        /* 文字垂直顶部对齐 */
        justify-content: flex-start;    /* 水平左对齐 */
        padding: 8px;                  /* 内边距 */
        box-sizing: border-box;
        # overflow: hidden;
      }
      .recommand-card .bottom .sub-container .sub-sub-container .top-child p {
        font-size: 11px;                /* 设置文字大小 */
        color: rgba(255, 255, 255, 0.6); /* 字体颜色 */
        text-align: left;               /* 文字左对齐 */
        text-overflow: ellipsis;        /* 超出部分显示省略号 */
        overflow: hidden;               /* 隐藏溢出文本 */
        display: -webkit-box;           /* 必须用于限制行数 */
        -webkit-box-orient: vertical;   /* 垂直排列 */
        -webkit-line-clamp: 7;          /* 限制显示两行文字 */
        margin: 0;                      /* 去除默认外边距 */
      }
      .recommand-card .bottom .sub-container .sub-sub-container .bottom-child {
        height: 100px;                  /* 下子容器固定高度 */
        width: 100%;                    /* 宽度占满父容器 */
        position: relative;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        position: relative;
        overflow: visible;
      }
      .recommand-card .bottom .sub-container .sub-sub-container .bottom-child .show-detail-link {
        position: absolute;              /* 绝对定位链接 */
        top: -2px;                       /* 距离顶部 10px */
        left: 10px;                     /* 距离右侧 10px */
        font-size: 14px;                 /* 链接文字大小 */
        color: rgba(255, 255, 255, 0.9);                   /* 链接文字颜色 */
        text-decoration: none;           /* 去掉下划线 */
        font-weight: 500;
        text-decoration: underline;
      }
      .recommand-card .bottom .sub-container .sub-sub-container .bottom-child .add-and-play {
        position: absolute;
        top: -28px;
        right: 4px;
        width: 50px;
        height: 45px;
        display: flex;
        align-items: flex-end;
        justify-content: flex-end;
        gap: 5px;
        border-radius: 20px;
      }
      
      #search_number_select {
        background-color: rgb(31, 31, 31);
        border: none;
        font-size: 16px; /* 字体大小 */
        color: #666; /* 字体颜色 */
        padding: 0px; /* 内边距 */
        width: 43px; /* 固定宽度 */
        border-radius: 50%; /* 圆角边框 */
        position: relative; 
        transform: translate(0px, 8px);
        outline: none;
      }
      #search_number_select:hover {
        # border-color: rgb(175, 175, 175);
        color: rgb(255, 255, 255, 0.8);
        outline: none; /* 确保聚焦时也没有边框 */
        box-shadow: none;
      }
      #search_number_select:focus {
        outline: none; /* 确保聚焦时也没有边框 */
        box-shadow: none;
      }
      
    "))
  ),
  div(
    class="container",
    div(
      class="main-container",
      div(
        class = "header", 
        div(
          class = "header-left",
          div(
            class="header-left-icon",
            tags$a(href = "https://open.spotify.com/", 
                   target = "_blank",  # 链接到外部网站，_blank 表示新标签页打开
                   tags$img(src = "Spotify_Primary_Logo_RGB_White.png")
            )
          )
        ),
        div(
          class = "header-middle",
          div(
            class="search_container",
            tags$img(
              src = "search_icon.webp", 
              style = "width: 24px; height: 24px; margin-right: 10px;"
            ),
            tags$input(
              id = "search_input",
              type = "text", 
              class = "search-input",
              placeholder = "What do you want to play?"
            ),
            uiOutput("dropdown_ui"),
            tags$div(
              style = "width: 1px; height: 24px; background-color: #666; margin: 0 12px;"
            ),
            selectInput(
              "search_number_select", NULL, # 无标题
              choices = c("6", "15", "30", "45", "60", "90"), # 选项
              selected = "6", # 默认值为 6
              selectize = FALSE, # 使用原生 HTML 下拉框
              width = "auto", # 宽度自动适应内容
            )
            # tags$span(
            #   HTML("&#9776;"), # Unicode
            #   style = "font-size: 22px; margin-right: 4px; color: #666;",
            #   id = "search-number-icon"
            # ),
            
          )
        ),
        div(
          class = "header-right",
          tags$img(
            src = "user_login.webp", # 替换为图片的实际路径或 URL
            style = "width: 60px; height: 60px; margin-right: 4px; cursor: pointer; user-drag: none; user-select: none;", # 设置样式
            draggable = "false"
          )
        ),
      ),
      div(
        class = "main", 
        div(
          # 显示歌曲和推荐指标
          class = "main-left",
          div(
            class = "main-left-top",
            uiOutput("main_song_box")
          ),
          div(
            class = "main-left-bottom",
            div(
              id = "plot-container",
              style = "height: 100%; width: 100%; overflow: hidden; position: relative; padding: 5px;",
              plotlyOutput("plot", height = "100%", width = "100%"),
              div(
                id = "info-icon",
                style = "position: absolute; bottom: 10px; right: 10px; 
                   width: 18px; height: 18px; border: 1px solid rgba(255, 255, 255, 0.8);
                   color: rgba(255, 255, 255, 0.8); border-radius: 50%; display: flex; 
                   align-items: center; justify-content: center; 
                   font-size: 12px; font-weight: bold; cursor: pointer;",
                "i",  # 图标内容
                title = HTML(
                  "Topic Entropy: Measures the thematic focus of each episode;
    Lower values indicate a single-topic focus,
    while higher values indicate coverage of multiple topics.

Emotional Disposition: Assesses the overall tone of each episode
    (positive, neutral, or negative) using sentiment analysis.

If you have any questions, please contact: jlu396@wisc.edu"
                )
                #title = "Topic Entropy: Measures the thematic focus of each episode; \n\t\t\tlower values indicate a single-topic focus, \n\t\t\twhile higher values indicate coverage of multiple topics.\nEmotional Disposition: Assesses the overall tone of each episode \n\t\t\t(positive, neutral, or negative) using sentiment analysis.\n\nIf you have any questions, please contact: jlu396@wisc.edu"
              )
            )
          )
        ),
        div(
          class = "main-right",
          div(
            class = "scrollable-content",
            div(
              class = "podcast_recommendation_title",
              div(class = "podcast_recommendation_title_font", 
                  "Episodes" #You Won't Want to Miss
              )
            ),
            div(
              class = "podcast_recommendations",
              # tags$div(id = "card-container", class = "recommand-card-container") # 大容器
              uiOutput("recommand_cards")
            )
          )
        ),
      ),
      div(
        class = "footer",
        div(
          class = "player-container",
          div(
            # 专辑图片&名称
            style = "width: 200px; height: 80px; position: absolute; bottom: 0px; left: 17px; display: flex;",
            div(
              style = "width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;",
              uiOutput("playing_image")
            ),
            div(
              style = "width: 120px; height: 80px;",
              uiOutput("song_box")
            )
          ),
          div(
            class = "player-container-center",
            div(
              # 播放控制
              class = "player-controls",
              tags$button(
                id = "play_repeat", 
                class = "player-controls-button", 
                tags$img(src = "shuffle_icon.svg")
              ),
              actionButton(
                "play_previous", 
                label = HTML("&#x25C2;"),
                class = "player-controls-button"
              ),
              div(
                style = "display: flex; align-items: center; justify-content: center;",
                actionButton("play_pause", 
                             label = HTML('<span class="offset-type-1">&#9654;</span>'),
                             class = "player-controls-button-play"),
              ),
              actionButton(
                "play_next", 
                label = HTML("&#x25B8;"),
                class = "player-controls-button"
              ),
              tags$button(
                id = "play_repeat", 
                class = "player-controls-button", 
                tags$img(src = "repeat_icon_default.svg")
              ),
            ),
            div(
              #时间条
              class = "time-bar-container",
              div(
                # 左时间
                class = "time-bar-left",
                style = "justify-content: flex-end; ",
                tags$span(id = "current_time", "00:00"), # 已播放时间
              ),
              div(
                class = "time-bar-center",
                # 音频播放器
                tags$audio(
                  id = "audio_player",
                  src = "https://podz-content.spotifycdn.com/audio/clips/7FHzB3EqnMgKkTUNuBo2Gd/clip_616760_676760.mp3",
                  type = "audio/mpeg",
                  hidden = TRUE # 隐藏默认播放器
                ),
                # 进度条
                tags$div(class = "progress-container",
                         tags$div(class = "progress-bar", id = "custom_progress_bar"),
                         tags$div(class = "boundary-marker", id = "boundary_marker") # 小红点标记
                )
              ),
              div(
                # 右时间
                class = "time-bar-right",
                tags$span(id = "total_time", "05:00")   # 总时长 (初始值)
              )
            )
          ),
          div(
            tags$img(
              src = "control_bar.png",
              style = "width: 200px; position: absolute; bottom: 2px; right: 17px;
              -webkit-user-drag: none; -moz-user-drag: none; -ms-user-drag: none; user-drag: none;"
            )
          )
        )
      )
    )
  ),
  
  tags$script(HTML("
    const audio = document.getElementById('audio_player');
    const progressBar = document.getElementById('custom_progress_bar');
    const progressContainer = document.querySelector('.progress-container');
    const boundaryMarker = document.getElementById('boundary_marker'); // 获取红点元素
    const currentTimeSpan = document.getElementById('current_time');
    const totalTimeSpan = document.getElementById('total_time');

    // 总音频时长 (完整音频的时长，单位：秒)
    let fullDuration = 300; // 例如，完整音频长度为 300 秒
    const totalProgressWidth = 480; // 总进度条宽度 (px)

    // 初始化总时长显示
    function formatTime(seconds) {
      const mins = Math.floor(seconds / 60);
      const secs = Math.floor(seconds % 60);
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    // 初始化：根据音频加载完成动态更新试听时长和总时长
    audio.addEventListener('loadedmetadata', function() {
      const clipDuration = audio.duration; // 试听片段时长
      totalTimeSpan.textContent = formatTime(fullDuration);
      
      // 设置红点位置
      const clipRatio = clipDuration / fullDuration;
      const markerPosition = clipRatio * totalProgressWidth; // 红点位置
      boundaryMarker.style.left = `${markerPosition}px`;
    });

    // 播放和暂停控制
    Shiny.addCustomMessageHandler('audio-control', function(message) {
      if (message.action === 'play') {
        audio.play();
      } else if (message.action === 'pause') {
        audio.pause();
      }
    });

    // 更新进度条和已播放时间
    audio.addEventListener('timeupdate', function() {
      const clipDuration = audio.duration; // 试听片段时长
      const playedRatio = audio.currentTime / clipDuration; // 当前播放时间与试听片段总时间的比例
      const progressWidth = playedRatio * totalProgressWidth * (clipDuration / fullDuration); // 计算进度条长度
      progressBar.style.width = `${progressWidth}px`;

      // 更新已播放时间
      currentTimeSpan.textContent = formatTime(audio.currentTime);
    });

    // 拖动逻辑修正，仅限试听片段范围
    function setAudioProgress(event) {
      const rect = progressContainer.getBoundingClientRect();
      const offsetX = event.clientX - rect.left;
      const clipDuration = audio.duration; // 试听片段时长

      // 限制拖动范围仅在试听片段内
      const clipRatio = clipDuration / fullDuration;
      const clipWidth = totalProgressWidth * clipRatio; // 试听片段对应的进度条长度

      if (offsetX <= clipWidth) {
        const newTimeRatio = offsetX / clipWidth; // 鼠标点击位置的时间比例 (仅限试听片段)
        const adjustedTime = newTimeRatio * clipDuration; // 调整后的时间
        audio.currentTime = Math.min(Math.max(adjustedTime, 0), clipDuration);
      }
    }
    // 鼠标点击或拖动调整进度
    progressContainer.addEventListener('mousedown', function(event) {
      setAudioProgress(event);
      progressContainer.addEventListener('mousemove', setAudioProgress);
    });
    progressContainer.addEventListener('mouseup', function() {
      progressContainer.removeEventListener('mousemove', setAudioProgress);
    });
    progressContainer.addEventListener('mouseleave', function() {
      progressContainer.removeEventListener('mousemove', setAudioProgress);
    });
  "))
  
)


server <- function(input, output, session) {
  # 防抖处理用户输入
  query_text <- debounce(reactive(input$search_input), 400)
  
  observeEvent(query_text(), {
    query <- query_text()
    # 如果输入框为空，隐藏下拉框
    if (is.null(query) || query == "") {
      output$dropdown_ui <- renderUI(NULL)
      return()
    }
    result <- spotify_search(query, token)
    shows_df <<- result$shows_df # 全局变量
    episodes_df <<- result$episodes_df
    # 调用函数获取动态结果
    tryCatch({
      results_ui <- show_search(shows_df, episodes_df, query, session)
    }, error = function(e) {
      # print(e)
      # print(shows_df)
      # print(episodes_df)
      results_ui <- div(
        class = "dropdown-item no-results",
        "No search results available"
      )
    })
    # 更新下拉框内容
    output$dropdown_ui <- renderUI({
      div(
        class = "dropdown show",
        results_ui
      )
    })
  }, ignoreInit = TRUE) # 忽略初始状态
  
  observeEvent(global_variable$id, {
    # print(paste("ID:", global_variable$id, "Type:", global_variable$type))
    # 清空输入框
    updateTextInput(session, "search_input", value = "")
    # 隐藏下拉菜单
    output$dropdown_ui <- renderUI(NULL)
    if (global_variable$type == "Episode") {
      result <- episodes_df[episodes_df$id == global_variable$id, ]
      global_episode$Podcast_ID <- NULL
      global_episode$Audio_Preview_URL <- result$audio_preview_url
      global_episode$Description <- result$description
      global_episode$Duration_MS <- result$duration_ms
      global_episode$External_URL <- result$external_urls.spotify
      global_episode$Episode_ID <- result$id
      global_episode$Image_640 <- result$image_640
      global_episode$Image_300 <- result$image_300
      global_episode$Image_64 <- result$image_64
      global_episode$Languages <- result$languages
      global_episode$Name <- result$name
      global_episode$Release_Date <- NULL
      global_episode$Info_shown <- combine_episode_info_text(result$release_date, result$duration_ms)
      global_episode$Type <- result$type
      avg_color <- calculate_rgb_mean_from_url(result$image_64)
      avg_r <- avg_color["avg_r"]
      avg_g <- avg_color["avg_g"]
      avg_b <- avg_color["avg_b"]
      global_episode$avg_color <- sprintf("rgba(%d, %d, %d, %.1f)", avg_r, avg_g, avg_b, 0.6)
      global_episode$avg_color_1 <- sprintf("rgba(%d, %d, %d, %.1f)", avg_r, avg_g, avg_b, 0.4)
      global_episode$avg_color_2 <- sprintf("rgba(%d, %d, %d, %.1f)", avg_r, avg_g, avg_b, 0)
    }else{
      result <- shows_df[shows_df$id == global_variable$id, ]
      global_episode$Podcast_ID <- result$id
      global_episode$Audio_Preview_URL <- NULL
      global_episode$Description <- result$description
      global_episode$Duration_MS <- NULL
      global_episode$External_URL <- result$external_urls.spotify
      global_episode$Episode_ID <- NULL
      global_episode$Image_640 <- result$image_640
      global_episode$Image_300 <- result$image_300
      global_episode$Image_64 <- result$image_64
      global_episode$Languages <- result$languages
      global_episode$Name <- result$name
      global_episode$Release_Date <- NULL
      global_episode$Info_shown <- combine_podcast_info_text(result$total_episodes)
      global_episode$Type <- result$type
      avg_color <- calculate_rgb_mean_from_url(result$image_64)
      avg_r <- avg_color["avg_r"]
      avg_g <- avg_color["avg_g"]
      avg_b <- avg_color["avg_b"]
      global_episode$avg_color <- sprintf("rgba(%d, %d, %d, %.1f)", avg_r, avg_g, avg_b, 0.6)
      global_episode$avg_color_1 <- sprintf("rgba(%d, %d, %d, %.1f)", avg_r, avg_g, avg_b, 0.4)
      global_episode$avg_color_2 <- sprintf("rgba(%d, %d, %d, %.1f)", avg_r, avg_g, avg_b, 0)
    }
    # search_change(TRUE)
    # print(result)
  })
  
  observeEvent(input$play_pause, {
    # 切换 play 的状态
    play(!play())
  })
  observe({
    # 更新按钮的图标
    if (!play()) {
      updateActionButton(session, "play_pause", label = HTML('<span class="offset-type-1">&#9654;</span>')) # 播放符号
      session$sendCustomMessage(type = "audio-control", message = list(action = "pause"))
    } else {
      updateActionButton(session, "play_pause", label = HTML('<span class="offset-type-2">&#10074;&#10074;<span>')) # 暂停符号
      session$sendCustomMessage(type = "audio-control", message = list(action = "play"))
    }
  })

  # 动态生成图片 HTML
  output$playing_image <- renderUI({
    tags$img(src = global_playing$Image_64, style = "width: 64px; height: 64px; border-radius: 8px;")
  })
  # 动态生成歌曲框
  output$song_box <- renderUI({
    tags$div(
      class = "song-box",
      tags$div(
        class = "song-title",
        tags$a(href = global_playing$External_URL, target = "_blank", global_playing$Name)
      )
    )
  })
  
  # 监听 selectInput 的变化，更新 reactiveVal
  observeEvent(input$search_number_select, {
    global_num_recommand(as.numeric(input$search_number_select)) # 更新 reactiveVal
  })
  
  output$main_song_box <- renderUI({
    tags$div(
      style = "display: flex; flex-direction: column; height: 100%; width: 100%; margin: 0; padding: 0; 
      box-sizing: border-box; min-height: 1000px; max-height: none; justify-content: flex-start;",
      # 上部区域
      tags$div(
        style = paste0("display: flex; height: 150px; width: 100%; flex-shrink: 0; flex-grow: 0; flex-basis: auto; background: ", global_episode$avg_color, ";"),
        # 左侧区域
        tags$div(
          style = "width: 150px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;",
          tags$img(
            src = global_episode$Image_300,  # 替换为图片链接
            style = "width: 135px; height: 135px; border-radius: 6px;"  # 设置图片样式
          )
        ),
        # 右侧区域
        tags$div(
          style = "flex: 1; display: flex; flex-direction: column; position: relative;",
          div(
            style = "height: 16px; margin-top: 6px; color: rgba(255, 255, 255, 0.6); font-size: 12px; 
            white-space: nowrap; overflow: hidden;",
            paste0(global_episode$Type, "                                         ")
          ),
          div(
            style = "
              display: -webkit-box; 
              -webkit-line-clamp: 3; 
              -webkit-box-orient: vertical; 
              overflow: hidden; 
              text-overflow: ellipsis; 
              word-wrap: break-word; 
              width: 100%; 
              box-sizing: border-box; 
              text-align: left;
              font-size: 18px;
              color: rgba(255, 255, 255, 0.9);
              font-weight: 800;
              margin-top: 3px;
            ",
            global_episode$Name
          ),
          div(
            style = "height: 10px; margin-top: 4px; color: rgba(255, 255, 255, 0.7); font-size: 14px; font-family: Verdana",
            global_episode$Info_shown
          ),
          actionButton(
            inputId = "main_play_button",  # 按钮 ID
            label = HTML('<span class="offset-type-1">&#9654;</span>'),  # 三角形图标
            class = "main-left-top-play-button"
          )
        )
      ),
      # 下部区域
      tags$div(
        style = paste0(
          "flex: 1; display: flex; flex-direction: column; padding: 0 7px;",
          "background: linear-gradient(to bottom, ", 
          global_episode$avg_color_1, " 0px, ",  # 起始颜色在 0%
          global_episode$avg_color_2, " 100px);"  # 结束颜色在指定百分比
        ),
        tags$div(
          style = "height: 30px; color: rgba(255, 255, 255, 0.9); font-size: 18px; font-weight: 600; margin-top: 5px;",
          "Description"
        ),
        tags$div(
          style = "
            display: block;
            white-space: normal;
            -webkit-line-clamp: 18; 
            -webkit-box-orient: vertical; 
            overflow: hidden; 
            word-wrap: break-word;
            word-break: break-word;
            overflow-wrap: break-word;
            width: 100%;
            box-sizing: border-box;
            color: rgba(255, 255, 255, 0.7);
            font-size: 14px;
            margin-top: 0px;
          ",
          global_episode$Description
        ),
        tags$a(
          href = global_episode$External_URL,  # 替换为目标链接
          "Details...",                 # 链接显示的文字
          style = "
            color: rgba(255, 255, 255, 0.9);                /* 链接文字颜色 */
            text-decoration: underline; /* 显示下划线 */
            cursor: pointer;            /* 鼠标变为手型 */
            margin-top: 10px;
          ",
          target = "_blank"             # 在新标签页打开链接
        ),
        tags$img(
          src = "spotify_copyright.webp",  # 替换为图片的实际链接
          style = "
            margin-top: 100px;
            width: 100%;  /* 宽度占满父容器 */
            height: auto; /* 高度按比例调整 */
            display: block; /* 避免图片下方出现多余间距 */
            -webkit-user-drag: none; -moz-user-drag: none; -ms-user-drag: none; user-drag: none;
          "
        ),
        tags$div(
          style = "height: 20px;"
        )
      )
    )
  })
  
  observeEvent(input$main_play_button, {
    if (is.null(global_episode$Audio_Preview_URL)) {
      # 显示通知
      showNotification("No audio source available", type = "error", duration = 2)
    } else {
      # 更新全局播放状态
      global_playing$Audio_Preview_URL <- global_episode$Audio_Preview_URL
      global_playing$External_URL <- global_episode$External_URL
      global_playing$Image_64 <- global_episode$Image_64
      global_playing$Duration_S <- global_episode$Duration_MS / 1000  # 转换为秒
      global_playing$Name <- global_episode$Name
      play(TRUE)
    }
  })
  
  
  # 绘制图表
  output$plot <- renderPlotly({
    print("绘图")
    req(global_search_result$df)  # 确保 df 已存在且不为空
    
    # 使用 global_search_result$df 绘制图表
    result_jitter <- global_search_result$df[, c("Normalized_Entropy", "Sentiment_Label_Num", "Name")]
    jitter_factor <- 0.005  # 抖动因子
    result_jitter$Normalized_Entropy <- global_search_result$df$Normalized_Entropy + 
      runif(nrow(global_search_result$df), -jitter_factor, jitter_factor)
    result_jitter$Sentiment_Label_Num <- global_search_result$df$Sentiment_Label_Num + 
      runif(nrow(global_search_result$df), -jitter_factor, jitter_factor)
    
    # 动态计算坐标轴范围
    x_range <- range(c(global_search_result$df$Normalized_Entropy, global_search_result$ec)) + c(-0.005, 0.005)
    y_range <- range(c(global_search_result$df$Sentiment_Label_Num, global_search_result$sln)) + c(-0.005, 0.005)
    
    # 使用 Plotly 绘制图表
    plot_ly() %>%
      add_trace(
        data = result_jitter,
        x = ~Normalized_Entropy,
        y = ~Sentiment_Label_Num,
        type = "scatter",
        mode = "markers",
        marker = list(color = "rgba(30, 215, 96, 0.7)", size = 6),
        name = "Recommand",
        text = ~paste0(
          "<b style='font-size:10px; color:#333;'>",
          "<span style='max-width:40px; display:inline-block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;'>",
          "Name: ", Name, "</span><br>",
          "Normalized Entropy: ", round(global_search_result$df$Normalized_Entropy, 3), "<br>",
          "Sentiment Label Num: ", round(global_search_result$df$Sentiment_Label_Num, 3), "<br>",
          "Sentiment Label: ", global_search_result$df$Sentiment_Label, "<br>",
          "Distance: ", round(global_search_result$df$Distance, 4),
          "</b>"
        ),
        hoverinfo = "text"
      ) %>%
      add_trace(
        x = ~global_search_result$ec,
        y = ~global_search_result$sln,
        type = "scatter",
        mode = "markers",
        marker = list(color = "rgba(255, 0, 0, 0.9)", size = 9),
        name = "Search",
        text = ~paste0(
          "<b style='font-size:11px; color:#333;'>",
          "<span style='max-width:40px; display:inline-block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;'>",
          "Name: ", Name, "</span><br>",
          "Normalized Entropy Num: ", round(global_search_result$ec, 3), "<br>",
          "Sentiment Label Num: ", round(global_search_result$sln, 3), "<br>",
          "Sentiment Label: ", global_search_result$sl,
          "</b>"
        ),
        hoverinfo = "text"
      ) %>%
      layout(
        # title = "Nearest Neighbors",
        plot_bgcolor = "rgba(0,0,0,0)",  # 图背景透明
        paper_bgcolor = "rgba(0,0,0,0)",  # 整个绘图区域透明
        xaxis = list(
          title = "Topic Entropy",
          range = x_range,
          color = "rgba(255, 255, 255, 0.8)",  # 坐标轴文字颜色
          showline = FALSE,  # 隐藏坐标轴线
          gridcolor = "rgba(255, 255, 255, 0.2)",  # 网格线颜色
          zeroline = FALSE,  # 隐藏零线
          tickcolor = "rgba(255, 255, 255, 0)",
          ticks = "none",
          ticklen = 0
        ),
        yaxis = list(
          title = "Emotional Disposition",
          range = y_range,
          color = "rgba(255, 255, 255, 0.8)",  # 坐标轴文字颜色
          showline = FALSE,  # 隐藏坐标轴线
          gridcolor = "rgba(255, 255, 255, 0.2)",  # 网格线颜色
          zeroline = FALSE,  # 隐藏零线
          tickcolor = "rgba(255, 255, 255, 0)",
          ticks = "none",
          ticklen = 0
        ),
        hoverlabel = list(
          bgcolor = "rgba(255, 255, 255, 0.1)",  # 背景颜色
          font = list(color = "#333", size = 12),  # 字体颜色和大小
          bordercolor = "rgba(255, 255, 255, 0)",
          borderwidth = 0,
          align = "left",
          borderradius = 8
        )
      )
  })
  
  
  # 监视 search_change <- reactiveValues(False) 的变化
  observe({
    print("搜索表格")
    # search_change(FALSE)
    description <- global_episode$Description
    analyze_result <- analyze_description(description)
    entropy_coords <- analyze_result$Normalized_Entropy
    sentiment_label_num <- analyze_result$Sentiment_Label_Num
    sentiment_label <- analyze_result$Sentiment_Label
    #print(entropy_coords)
    #print(sentiment_label_num)
    #print(analyze_result$Sentiment_Label)
    global_search_result$df <- find_nearest_neighbors(entropy_coords, sentiment_label_num, global_num_recommand())
    global_search_result$ec <- entropy_coords
    global_search_result$sln <- sentiment_label_num
    global_search_result$sl <- sentiment_label
    # print(global_search_result)
  })
 
  # 动态生成卡片列表
  output$recommand_cards <- renderUI({ # 匹配的名称
    print("生成卡片")
    div(class = "recommand-card-container",
      lapply(1:nrow(global_search_result$df), function(i) {
        row <- global_search_result$df[i, ]
        rgb_values <- calculate_rgb_mean_from_url(row$Image_64)
        rgba_value <- paste0("rgba(", paste(rgb_values, collapse = ", "), ", 0.6)")
        rgba_value_2 <- rgb_values*0.6+6.8
        rgba_value_3 <- paste0(
          "background: linear-gradient(to bottom right, rgba(", 
          paste(rgba_value_2, collapse = ", "), ", 0) 0%, rgba(", 
          paste(rgba_value_2, collapse = ", "), ", 1) 30%);"
        )
        episode_info_shown <- combine_episode_info_text(row$Release_Date, row$Duration_MS)
        div(
          id = id_generator(),
          class = "recommand-card",
          style = paste0("background: ", rgba_value, ";"),
          div(
            class = "top", 
            div(
              class = "top-upper", 
              h5(row$Name)
            ),
            div(
              class = "top-lower", 
              episode_info_shown
            )
          ),
          div(
            class = "middle", 
            tags$img(src = row$Image_300)
          ),
          div(
            class = "bottom", 
            div(
              class = "sub-container",
              div(
                class = "sub-sub-container",
                div(
                  class = "top-child",
                  p(row$Description)
                ),
                div(
                  class = "bottom-child",
                  a(href = row$External_URL, 
                    class = "show-detail-link", 
                    "Details..."
                  ),
                  div(
                    class = "add-and-play", 
                    style = rgba_value_3,
                    tags$img(src = "add_playlist_icon.svg", 
                             style = "width: 20px; height: 20px;"),
                    tags$img(src = "play_icon.svg", 
                             style = "width: 40px; height: 40px; border-radius: 50%; 
                              "),
                    # style = paste0("background: ", rgba_value, ";"),
                  )
                )
              )
            )
          )
        )
      })
    )
  })
 
  
}


shinyApp(ui = ui, server = server, options = list(javascript = js))
